/**
 * Variables
 */
// url of the api
let urlAPI = "http://localhost:9000/";
// obj task
let taskData = {};
taskData.task = "Réaliser le projet"; 

/**
 * Fonctions
 */

// get
function getData(url) {
    let req = new XMLHttpRequest();
    req.open("GET", url);
    req.addEventListener("load", function () {
        if (req.status >= 200 && req.status < 400) {
            console.log(this.responseText);
        } else {
            console.error(req.status + " " + req.statusText + " " + url);
        }
    });
    req.addEventListener("error", function () {
        console.error("Erreur réseau avec l'URL " + url);
    });
    req.send(null);
}

// Post
function postData(url, data) {
    let req = new XMLHttpRequest();
    req.open("POST", url);
    req.addEventListener("load", function () {
        if (req.status >= 200 && req.status < 400) {
            console.log(this.responseText);
        } else {
            console.error(req.status + " " + req.statusText + " " + url);
        }
    });
    req.addEventListener("error", function () {
        console.error("Erreur réseau avec l'URL " + url);
    });
    req.setRequestHeader("Content-Type", "application/json");
    data = JSON.stringify(data);
    req.send(data);
}


/**
 * Execution
 */
// get the url => data
getData(urlAPI);
// post to the url => data
postData(urlAPI, taskData);